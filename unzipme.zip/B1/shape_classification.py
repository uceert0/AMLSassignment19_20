import numpy as np

from tqdm import tqdm
from sklearn.model_selection import train_test_split
from sklearn.decomposition import PCA
from sklearn.metrics import accuracy_score
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis


class model_B1:
    def __init__(self, features, labels, test_size=0.3):
        self.test_size = test_size
        self.dataset, self.labels = self.create_dataset(features, labels)

        self.train_set, self.test_set, self.train_lbls, self.test_lbls = \
            self.create_train_test_sets()

        self.pca = None
        self.clf = None
        self.train_accuracy = None
        self.test_accuracy = None

    @staticmethod
    def create_dataset(db_features, db_labels):
        """Function that creates the dataset and corresponding labels"""
        X = np.zeros((len(db_features), db_features[0].shape[0]))
        y = np.zeros((len(db_features), 1))

        for i, feat in tqdm(enumerate(db_features)):
            X[i, :] = feat
            y[i] = db_labels[str(i)]

        return X, y

    def create_train_test_sets(self):
        """Create train and test sets"""
        X_train, X_test, y_train, y_test = train_test_split(self.dataset,
                                                            self.labels,
                                                            test_size=self.test_size,
                                                            random_state=1)

        return X_train, X_test, y_train, y_test

    def train_model(self, train_set, train_labels, percentage_variance=0.97):
        print('training model (PCA+LDA)')
        """Train classification model"""
        pca = PCA(n_components=percentage_variance)
        projected_data = pca.fit_transform(train_set)

        clf = LinearDiscriminantAnalysis()
        clf.fit(projected_data, np.ravel(train_labels))
        train_accuracy = accuracy_score(train_labels, clf.predict(
            projected_data))

        self.pca = pca
        self.clf = clf
        self.train_accuracy = train_accuracy

    def test_model(self, test_set, test_labels):
        print('running inference')
        projected_data = self.pca.transform(test_set)
        self.test_accuracy = accuracy_score(test_labels, self.clf.predict(
            projected_data))

    def test_external_dataset(self, features, labels):
        test_dataset, test_labels = self.create_dataset(features, labels)
        print('running inference')
        projected_data = self.pca.transform(test_dataset)
        return accuracy_score(test_labels, self.clf.predict(
            projected_data))