import os
import csv
import cv2
import numpy as np
import glob
from natsort import natsorted


from tqdm import tqdm
from configuration import DB_PATH_INIT, DB_PATH_PREPRO, TASK2COL_CELEBA,  \
    TASK2COL_CARTOON, DB_PATH_FEATURES
from functions.utils import process_batch_imgs, extract_features_batch_imgs


class Database:
    """Class for creating database for a given task, load label,
    and preprocess images"""
    def __init__(self, db_name, db_task, area_extract='face',
                 feature_extract='igo', db_init_path=DB_PATH_INIT,
                 db_perpo_path=DB_PATH_PREPRO,
                 db_features_path=DB_PATH_FEATURES):

        self.db_name = db_name
        self.db_init_imgs_path = os.path.join(db_init_path, db_name, 'img')
        self.db_labels_path = os.path.join(db_init_path, db_name, 'labels.csv')

        # Create folder for preprocessed images
        _path = os.path.join(db_perpo_path, db_name, db_task)
        if not os.path.exists(_path):
            os.makedirs(_path)
        self.db_perpo_path_img = _path

        # Create folder for extracted features
        _path = os.path.join(db_features_path, db_name, db_task)
        if not os.path.exists(_path):
            os.makedirs(_path)
        self.db_features = _path

        self.task = db_task
        self.area_extract = area_extract
        self.labels = dict()
        self.feature_extract = feature_extract

    def read_labels(self):
        """Function for reading the labels of the images for a specific task"""

        if self.db_name in ['celeba', 'celeba_test']:
            column = TASK2COL_CELEBA[self.task]
        elif self.db_name in ['cartoon_set', 'cartoon_set_test']:
            column = TASK2COL_CARTOON[self.task]

        with open(self.db_labels_path) as csv_file:
            csv_reader = csv.reader(csv_file, delimiter='\t')
            line_count = 0
            for row in csv_reader:
                if line_count == 0:
                    line_count += 1
                    continue
                self.labels[row[0]] = row[column]
                line_count += 1

    def preprocess_images(self):
        print('preprocessing images')
        process_batch_imgs(self.db_init_imgs_path, self.db_perpo_path_img,
                           area=self.area_extract)

    def extract_features(self):
        print('extracting features')
        extract_features_batch_imgs(self.db_perpo_path_img,
                                    self.db_features, self.feature_extract)

    def read_database(self):
        print('reading dataset')
        all_features = []
        all_features_paths = glob.glob(self.db_features + '/*.npy')
        all_features_paths = natsorted(all_features_paths)

        for im_path in tqdm(all_features_paths):
            feat = np.load(im_path)
            all_features.append(feat)
        return all_features



