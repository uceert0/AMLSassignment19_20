import cv2
import numpy as np
import os
import glob
import warnings

from configuration import FACE_DET_PATH
from tqdm import tqdm
from natsort import natsorted


def crop_img_square(image, bbox, new_dim, bbox_expand):
    """Crop image based on the given bounding box

    Args:
        image (ndarray): image
        bbox (x_tl,y_tl, w,h): bounding box
        new_dim (int): the size of cropped image (square)
        bbox_expand (float): expand bounding box

    Returns:
        cropped_image: cropped image
    """
    x, y, w, h = bbox

    # Find center of bbox
    center_bbox = np.array([x + w / 2, y + h / 2])

    # Compute bbox's length as the mean of bbox's width and height
    size_bbox = (w + h) / 2

    # Compute center of square bbox
    distance_translate_center = bbox_expand * size_bbox / 2

    # Create square bbox
    tl = center_bbox - distance_translate_center
    br = center_bbox + distance_translate_center

    # Constrain bbox inside image
    tl[0] = max(tl[0], 0)
    tl[1] = max(tl[1], 0)

    br[0] = min(br[0], image.shape[1] - 1)
    br[1] = min(br[1], image.shape[0] - 1)

    cropped_image = image[int(tl[1]):int(br[1]), int(tl[0]):int(br[0]), :]
    cropped_image = cv2.resize(cropped_image, (new_dim, new_dim))

    return cropped_image


def detect_face(image, face_cascade):
    """Method that detects face on the given image

    Args:
        image (ndarray): image
        face_cascade (cv2.CascadeClassifier): face detector

    Returns:
        (x, y, w, h): bounding box of detected faces
    """
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray, 1.1, 5)

    if len(faces) > 0:
        return faces[0]
    else:
        return None


def process_batch_imgs(path_read, path_save, new_dim=60, bbox_expand=1.2,
                       cascade_path=FACE_DET_PATH, area='face'):
    """Process images from the given folder

    Args:
        path_read (str): folder to read images from
        path_save (str): destination folder
        new_dim (int): save of preprocessed image
        bbox_expand (float): expand bounding box

    Returns:
        save images to path_save
    """
    face_cascade = cv2.CascadeClassifier(cascade_path)

    all_images_path = glob.glob(os.path.join(path_read, '*.jpg'))
    if len(all_images_path) == 0:
        all_images_path = glob.glob(os.path.join(path_read, '*.png'))
    all_images_path = natsorted(all_images_path)

    if len(all_images_path) == 0:
        warnings.warn('provided folder does not contain images')
        return

    for img_path in tqdm(all_images_path):
        # Read image
        img = cv2.imread(img_path)

        # Detect face
        bbox = detect_face(img, face_cascade)

        # Crop face
        if bbox is not None:
            img = crop_img_square(img, bbox, new_dim, bbox_expand)
        else:
            img = cv2.resize(img, (new_dim, new_dim))

        if area == 'mouth':
            img = img[int(img.shape[0]*(1.2/2)):, :, :]
        elif area == 'eyes':
            img = img[:int(img.shape[0] * (1.2 / 2))+1, :, :]

        # Export image
        file_name = os.path.split(img_path)[-1]
        cv2.imwrite(os.path.join(path_save, file_name), img)


def extract_igo_features(img):
    """Function to extract image gradient orientations from the given image

     Args:
         img (ndarray): image

     Rerturns:
        igo_pixels_x (ndarray) igo x direction
        igo_pixels_y (ndarray) igo y direction
     """
    if len(img.shape) == 3:
        img = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)

    grad_x = cv2.Sobel(img, cv2.CV_32F, 1, 0, ksize=3)
    grad_y = cv2.Sobel(img, cv2.CV_32F, 0, 1, ksize=3)

    # compute angles
    grad_orient = np.angle(grad_x + 1j * grad_y)
    # compute igo image
    igo_pixels_x = np.sin(grad_orient)
    igo_pixels_y = np.cos(grad_orient)

    return igo_pixels_x, igo_pixels_y


def extract_features_batch_imgs(path_read, path_save, feature='igo'):
    """Extract features from images in  given folder

    Args:
        path_read (str): folder to read images from
        path_save (str): destination folder

    Returns:
        save extracted features
    """

    all_images_path = glob.glob(os.path.join(path_read, '*.jpg'))
    if len(all_images_path) == 0:
        all_images_path = glob.glob(os.path.join(path_read, '*.png'))
    all_images_path = natsorted(all_images_path)

    if len(all_images_path) == 0:
        warnings.warn('provided folder does not contain images')
        return

    for img_path in tqdm(all_images_path):
        # Read image
        img = cv2.imread(img_path)
        
        file_name = os.path.split(img_path)[-1].split('.')[0]+'.npy'

        if feature == 'igo':
            img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            igo_x, igo_y = extract_igo_features(img)

            extracted_features = []
            extracted_features.extend(igo_x.flatten())
            extracted_features.extend(igo_y.flatten())

            np.save(
                os.path.join(path_save, file_name), extracted_features)
        elif feature == 'rgb':
            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            extracted_features = []
            extracted_features.extend(img.flatten())           
            np.save(
                os.path.join(path_save, file_name), extracted_features)